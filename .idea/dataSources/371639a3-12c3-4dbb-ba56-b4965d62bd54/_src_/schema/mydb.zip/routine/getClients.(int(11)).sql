CREATE PROCEDURE getClients(IN personID INT)
  BEGIN
  SELECT * FROM clients WHERE personID=1;
END;
